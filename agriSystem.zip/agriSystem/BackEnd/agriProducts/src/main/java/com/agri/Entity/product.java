package com.agri.Entity;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import java.util.*;

@Entity
public class product{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long Id;

    @CreationTimestamp
    private Date creationTimeStamp;
    
    private String productName;
    
    private String unitPrice;
    
    private int weight;
    private String manufacturedLocation;
    private Date manufacturedDate;
    private String description;
    
    @ManyToOne
    @JoinColumn(name="productCategoryId")
    private productCategory productCategory;
    
    @ManyToOne
    @JoinColumn(name="stockId")
    private stock stock;

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public Date getCreationTimeStamp() {
		return creationTimeStamp;
	}

	public void setCreationTimeStamp(Date creationTimeStamp) {
		this.creationTimeStamp = creationTimeStamp;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getManufacturedLocation() {
		return manufacturedLocation;
	}

	public void setManufacturedLocation(String manufacturedLocation) {
		this.manufacturedLocation = manufacturedLocation;
	}

	public Date getManufacturedDate() {
		return manufacturedDate;
	}

	public void setManufacturedDate(Date manufacturedDate) {
		this.manufacturedDate = manufacturedDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public productCategory getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(productCategory productCategory) {
		this.productCategory = productCategory;
	}

	public stock getStock() {
		return stock;
	}

	public void setStock(stock stock) {
		this.stock = stock;
	}

    
	
}