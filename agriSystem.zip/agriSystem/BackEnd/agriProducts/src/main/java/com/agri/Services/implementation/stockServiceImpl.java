package com.agri.Services.implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agri.Entity.stock;
import com.agri.Repository.stockRepository;
import com.agri.Services.stockService;

@Service
public class stockServiceImpl implements stockService{
	
	@Autowired
	stockRepository stockRepository;

	@Override
	public boolean saveStock(stock stock) {
		try {
			stockRepository.save(stock);
			return true;
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}
	
	

}
