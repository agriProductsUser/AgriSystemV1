package com.agri.Services.implementation;



import org.apache.log4j.spi.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agri.Entity.product;
import com.agri.Repository.productRepository;
import com.agri.Services.productService;

@Service
public class productServiceImpl implements productService{

	@Autowired
	productRepository productRepo;
	
//	private static final Logger LOGGER = LoggerFactory.getLogger(productServiceImpl.class);
	
	@Override
	public boolean saveProducts(product product) {
		try {
			productRepo.save(product);
			return true;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
		
	}

	
	
}