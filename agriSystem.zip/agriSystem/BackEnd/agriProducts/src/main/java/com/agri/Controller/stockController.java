package com.agri.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.agri.Entity.stock;
import com.agri.Services.stockService;


@RestController
@RequestMapping("/stock")
public class stockController{
	
	@Autowired
	stockService stockService;
	
	
	@RequestMapping(value="/saveStock", method= RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<?> saveStock(@RequestBody stock stock){
		try {
			
			return ResponseEntity.ok(stockService.saveStock(stock));
		
		}catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
	}
}
