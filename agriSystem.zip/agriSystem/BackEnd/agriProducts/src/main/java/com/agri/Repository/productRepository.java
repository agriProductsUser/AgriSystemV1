package com.agri.Repository;

import org.springframework.stereotype.Repository;

import com.agri.Entity.product;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface productRepository extends JpaRepository<product, Long>{
	
	
}

