package com.agri.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.agri.Entity.deliverer;

@Repository
public interface delivererRepository extends JpaRepository<deliverer,Long>{

	
}
