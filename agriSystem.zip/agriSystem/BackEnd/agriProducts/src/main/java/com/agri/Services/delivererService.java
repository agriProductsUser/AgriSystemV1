package com.agri.Services;

import com.agri.Entity.deliverer;

public interface delivererService {

	public boolean saveDeliverer (deliverer deliverer);
	
}
