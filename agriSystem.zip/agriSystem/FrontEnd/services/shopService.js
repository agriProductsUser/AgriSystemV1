angular.module('agri').factory('shopService',function (GenericAjaxGenerator,CONSTANT){
    return{


    }

})